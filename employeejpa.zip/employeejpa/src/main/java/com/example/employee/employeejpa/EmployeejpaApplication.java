package com.example.employee.employeejpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeejpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeejpaApplication.class, args);
	}

}
